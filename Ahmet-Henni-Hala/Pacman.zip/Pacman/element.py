    mur1 = Mur()
    mur1.rect.x = p[0]
    mur1.rect.y = p[1]
    gpe_murs.add(mur1)
    
    #fenetre.blit(pygame.transform.scale(fond, size),(0,0))
    gpe_murs.draw(fenetre)
    
    
    
gpe_murs = pygame.sprite.Group()    


#for p in places:
    #fenetre.blit(pygame.transform.scale(imageMur, (30,30)),p)
    
    #pygame.display.flip()
    
    
    
    
#places = [(0,20),(20,20),(40,20),(60,20),(80,20),(80,40),(80,60),(100,60),(120,60),(140,60),(160,60),(180,60),(200,60),(400,100),(420,100),(440,100),(460,100),(480,100),(500,100),(520,100),(540,100),(540,120),(540,140),(540,160),(560,160),(580,160),(600,160),(600,140),(600,120),(600,100),(600,80),(500,440),(500,460),(500,480),(500,500)]

fenetre.blit(pygame.transform.scale(imageMur, (40,40)),(0,0))







#-----------------------MUR-----------------------
class Mur():
    
    def __init__(self):
        # Call the parent class (Sprite) constructor
        super().__init__()
        
        # on connait la taille de notre image
        self.image = pygame.Surface([30,30])
        self.image.fill(WHITE)
        self.image.set_colorkey(WHITE)
        # defini une image pour le mur
        self.image = pygame.image.load("mur.png").convert_alpha()
 
        # Fetch the rectangle object that has the dimensions of the image.
        self.rect = self.image.get_rect()
        
        
        
        
        
 
 
 
playerPacman = Pacman(45 ,30 ,4)
playerPacman.rect.x = 200
playerPacman.rect.y = 150       
        
gpe_pacman = pygame.sprite.Group()
gpe_pacman.add(playerPacman)   
        
gpe_cars.draw(fenetre)
gpe_murs.draw(fenetre)   
        
        
        
        
class Pacman(pygame.sprite.Sprite):
    
    
    
    def __init__(self, color, width, height, vitesse=5):
        
        super().__init__()
            
        self.image = pygame.Surface([width, height])
        self.image.fill(WHITE)
        self.image.set_colorkey(WHITE)    
            
        self.image = pygame.image.load("pacman.png").convert_alpha()
        self.mask = pygame.mask.from_surface(self.image)
        self.rect = self.image.get_rect()
        self.vitesse = vitesse
        self.bloque = None
        pygame.display.flip()
        fenetre.blit(pygame.transform.scale(self.image, (30,30)))
        
        
        
        
        
        
    #Add this draw function so we can draw individual sprites
    def draw(self, screen):
        screen.blit(self.image, self.rect)

    #Sauvegarde la direction qui a produit le contact
    def collision_sol(self,direction):
        if self.bloque == None:
            self.bloque = direction
        elif self.bloque != direction:
            self.bloque = None
            
            
            
            
            
            
perso = Pacman()
perso.rect=(10,10)
pygame.display.flip()











# Déplacement de Pacman
        if event.type== KEYDOWN:
            if event.key in DIRECTION:
                        if (pygame.sprite.collide_mask(playerPacman,montagnes)):
                            mess = "Tu a été touché"
                            print(pygame.sprite.collide_mask(montagnes,playerPacman),event.key)
                            playerPacman.collision_sol(event.key)
                        else:
                            playerPacman.bloque = None

                        playerPacman.avance(event.key)
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
# Déplacement de Pacman
        if event.type== KEYDOWN:
            if event.key in DIRECTION:
                        if (pygame.sprite.collide_mask(playerPacman)):
                            mess = "Tu a été touché"
                            print(pygame.sprite.collide_mask(playerPacman),event.key)
                            playerPacman.collision_sol(event.key)
                        else:
                            playerPacman.bloque = None

                        playerPacman.avance(event.key)

        # Test la collision entre un sprite et un groupe de sprites pixel perfect
        collision=pygame.sprite.spritecollide(playerPacman,gpe_murs, False, pygame.sprite.collide_mask)
        if collision:
            mess = " Collision avec les murs"


continuer=True
perso = playerPacman()
pygame.display.flip()
while True:
    perso.draw(fenetre)
    for event in pygame.event.get():
        if event.type == pygame.QUIT: 
            pygame.quit()
            sys.exit(0)
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        # Déplacement de Pacman
        if event.type== KEYDOWN:
            if event.key in DIRECTION:
                        if (pygame.sprite.collide_mask(playerPacman)):
                            mess = "Tu a été touché"
                            print(pygame.sprite.collide_mask(playerPacman),event.key)
                            playerPacman.collision_sol(event.key)
                        else:
                            playerPacman.bloque = None

                        playerPacman.avance(event.key)

        # Test la collision entre un sprite et un groupe de sprites pixel perfect
        collision=pygame.sprite.spritecollide(perso,gpe_murs, False, pygame.sprite.collide_mask)
        if collision:
            mess = " Collision avec les murs"