from math import *
from random import randint

print("J'ai choisi un nombre entre 1 et 25. A toi de le deviner en 5 tentatives au maximum !")

random = randint(1,25)

choix1 = int(input("Entre ton premier choix : "))

if choix1 < random:
    print(choix1,"Haha, trop petit")
elif choix1 > random:
    print(choix1,"Haha, trop grand")
else:
    print(choix1, "C'est sa")

choix2 = int(input("Entre ton deuxième choix : "))

if choix2 < random:
    print(choix2,"Encore raté, trop petit")
elif choix2 > random:
    print(choix2,"Encore raté, trop grand")
else:
    print(choix2, "C'est sa")

choix3 = int(input("Entre ton troisième choix : "))

if choix3 < random:
    print(choix3,"Réfléchie, trop petit")
elif choix3 > random:
    print(choix3,"Réfléchie, trop grand")
else:
    print(choix3, "C'est sa")

choix4 = int(input("Entre ton quatrième choix : "))

if choix4 < random:
    print(choix4,"Tes nul, trop petit")
elif choix4 > random:
    print(choix4,"Tes nul, trop grand")
else:
    print(choix4, "C'est sa")

choix5 = int(input("Entre ton cinquième choix : "))

if choix5 < random:
    print(choix5,"Tu est déséspérant, trop petit")
elif choix5 > random:
    print(choix5,"Tu est déséspérant, trop grand")
else:
    print(choix5, "C'est sa")

print("Bien joué, voici toute tes tentatives:", choix1,",", choix2,",", choix3,",", choix4,",", choix5)
print("La bonne réponse était", random, "Haha c'est évident'")